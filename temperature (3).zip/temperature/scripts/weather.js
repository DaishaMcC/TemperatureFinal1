function getTEMP(){
    var celsius= Number(prompt("Enter Celsius number here"));

    var fahrenheit=(celsius*9/5)+ 32;

    var fahrenheitTemperature = document.getElementById("weather")
    fahrenheitTemperature.innerHTML +=
    `<p>Temp: ${fahrenheit}</p>`
}