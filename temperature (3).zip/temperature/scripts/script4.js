
for(let i=10; i<=100; i++){
    console.log("Loop line " + i);
}

function muliTable(){
    console.log("Multiplication table x5")
    for(let i=1;i<=10;i++){
        document.write(`<p> ${i} x 5 = ${i*5}<p>`);
    }
}