let startTemp = Number(prompt("Enter start temperature"));
let endTemp = Number(prompt("Enter end temperature"));
let scale = (prompt("Enter 'C' for celsius or 'F' for fahrenheit"))
document.getElementById("weather").innerHTML = result; 


function convertTemperatureRange(){
    for(let temperature=startValue; temperature<=endValue; temperature++){
        if(scale.toUpperCase() == "C"){
            let fahrenheit=(temperature*9/5)+ 32;
            result.innerHTML += celsius +=
            `<p>TempC: ${celsius}</p>`
        }else if (scale.toUpperCase == "F"){
            let celsius=(temperature-32)* 5/9;
            console.log(celsius); // math operation
            result.innerHTML += fahrenheit += 
            `<p>TempF: ${fahrenheit}</p>`
    }else{
        return "Invalid scale. Please enter 'C' or 'F'";
    };

}
return result;
}
//var celsius=(temperature-32)* 5/9;
//var fahrenheit=(temperature*9/5)+ 32;
// promt user to enter start temp an ending temp and scale either c or f
// scale more informaiton
// document write loop somehow
// so many questionss

