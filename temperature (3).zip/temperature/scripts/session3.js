// Exercise: Guess the Number Game

// 1. Generate a random number between 1 and 10 (you can use Math.random() and Math.floor()).
// 2. Ask the user to guess the number. (prompt)
// 3. Use an if-else statement to check if the user's guess is correct.
// 4. If the guess is correct, print "Congratulations! You guessed the number."
// 5. If the guess is incorrect, print "Sorry, that's not correct. The number was [generated number]".

function guessNumber(){
    let randomNumber=Math.floor(Math.random()*10)+1;
    console.log(randomNumber)

    let userGuess = prompt("Guess the number between 1 and 10");
    let results = document.getElementById("results");
    if(userGuess == randomNumber){
    results.innerHTML="Congratulations! you guessed the correct number";
}else{
    results.innerHTML="Sorry, that's not correct. The number was" + randomNumber;
}
}


// Challenge: Driving License

// 1. Prompt the user to enter their age.
// 2. Use an if-else statement to determine if the person can get a driving license.
// 3. If the age is 18 or older, print "Congratulations! You can get your driving license."
// 4. If the age is less than 18, print "Sorry, you are too young to get a driving license."

function getDriverLicense(){
    
    let age = prompt("Enter your age");
    if(age>=18){
    console.log("Congratulations! You can get your drivers license")
    }else{
        console.log("Sorry, you are too young")
    }
}

function login(){
    let userNameDB= "student@sdgku.edu";
    let userPassDB= "Test1234";

    let userName=prompt("Enter your username");
    let userPass=prompt("Test1234")
    
    if(userName==userNameDB && userPass==userPassDB){
    console.log("Welcome to the system:");
    }else{
        console.log("Invalid credentials");
    }
}